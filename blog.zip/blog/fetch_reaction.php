<?php
try {
    $pdo = new PDO('mysql:host=localhost;dbname=blog;charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    error_log("Database connection established.");
} catch (PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $post_id = isset($_GET['post_id']) ? filter_input(INPUT_GET, 'post_id', FILTER_VALIDATE_INT) : 0;

    if ($post_id <= 0) {
        error_log("Invalid data: post_id=$post_id");
        echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
        exit;
    }

    // Log for debugging
    error_log("Fetching reactions for post_id=$post_id");

    $stmt = $pdo->prepare("SELECT 
        SUM(CASE WHEN reaction_type = 'like' THEN 1 ELSE 0 END) AS likes, 
        SUM(CASE WHEN reaction_type = 'dislike' THEN 1 ELSE 0 END) AS dislikes 
        FROM post_reactions WHERE post_id = ?");
    $stmt->execute([$post_id]);
    $reactions = $stmt->fetch(PDO::FETCH_ASSOC);

    // Log the fetched reactions for debugging
    error_log("Fetched reactions: " . json_encode($reactions));

    echo json_encode([
        'status' => 'success',
        'likes' => $reactions['likes'] ?? 0,
        'dislikes' => $reactions['dislikes'] ?? 0
    ]);
}
?>
