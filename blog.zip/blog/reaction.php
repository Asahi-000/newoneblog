<?php
session_start();

try {
    $pdo = new PDO('mysql:host=localhost;dbname=blog;charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    $post_id = isset($data['post_id']) ? filter_var($data['post_id'], FILTER_VALIDATE_INT) : 0;
    $reaction_type = isset($data['reaction_type']) ? filter_var($data['reaction_type'], FILTER_SANITIZE_STRING) : '';

    if (!$post_id || !in_array($reaction_type, ['like', 'dislike'])) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("SELECT * FROM post_reactions WHERE post_id = ? AND user_id = ?");
        $stmt->execute([$post_id, $user_id]);
        $reaction = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($reaction) {
            // If reaction exists and is the same, remove it (toggle reaction off)
            if ($reaction['reaction_type'] === $reaction_type) {
                $stmt = $pdo->prepare("DELETE FROM post_reactions WHERE id = ?");
                $stmt->execute([$reaction['id']]);
                echo json_encode(['status' => 'success', 'action' => 'removed']);
            } else {
                // Update reaction type
                $stmt = $pdo->prepare("UPDATE post_reactions SET reaction_type = ? WHERE id = ?");
                $stmt->execute([$reaction_type, $reaction['id']]);
                echo json_encode(['status' => 'success', 'action' => 'updated']);
            }
        } else {
            $stmt = $pdo->prepare("INSERT INTO post_reactions (post_id, user_id, reaction_type) VALUES (?, ?, ?)");
            $stmt->execute([$post_id, $user_id, $reaction_type]);
            echo json_encode(['status' => 'success', 'action' => 'added']);
        }
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
?>
 