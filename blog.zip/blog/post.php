<?php

    include 'partials/header.php';

    try {
        $pdo = new PDO('mysql:host=localhost;dbname=blog;charset=utf8', 'root', '');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die('Database connection failed: ' . $e->getMessage());
    }    
    
    // Get the post ID from the URL
    $post_id = isset($_GET['post_id']) ? (int)$_GET['post_id'] : 0;
    
    // Include the functions file which contains the show_comments function
    include_once('functions.php'); 

    // Call show_comments and pass the PDO object and post ID
    echo show_comments($pdo, $post_id);


    if(isset($_GET['ID'])){
        $ID = filter_var($_GET['ID'], FILTER_SANITIZE_NUMBER_INT);
        $query = "SELECT * FROM posts WHERE ID=$ID";
        $result = mysqli_query($conn, $query);
        $post = mysqli_fetch_assoc($result);
    }
    else{
        header('Location: '.ROOT_URL. 'blog.php');
        die();
    }

?>

    <section class="singlepost">
        <div class="singlepost_container">
            <h2><?= $post['title'] ?></h2>
            <div class="post_author">
                <?php 
                    $author_id = $post['author_id'];
                    $author_query = "SELECT * FROM users WHERE ID=$author_id";
                    $author_result = mysqli_query($conn, $author_query);
                    $author = mysqli_fetch_assoc($author_result);
                ?>
                <div class="post_author-avatar">
                    <img src="./images/<?= $author['avatar'] ?>" alt="">
                </div>
                <div class="post_author-info">
                    <h5>By: <?= "{$author['firstname']} {$author['lastname']}" ?></h5>
                    <small><?= date("M d, Y - H:i", strtotime($post['date_time'])) ?></small>
                </div>
            </div>
            <div class="singlepost_thumbnail">
                <img src="./images/<?= $post['thumbnail'] ?>" alt="">
            </div>
            <p><?= $post['body'] ?></p>
            
            <br><br>

            <?php
            function get_reactions($pdo, $post_id) {
                $stmt = $pdo->prepare("SELECT 
                    SUM(reaction_type = 'like') AS likes, 
                    SUM(reaction_type = 'dislike') AS dislikes 
                    FROM post_reactions WHERE post_id = ?");
                $stmt->execute([$post_id]);
                return $stmt->fetch(PDO::FETCH_ASSOC);
            }

            // Fetch reactions for the post
            $post_id = isset($_GET['post_id']) ? filter_input(INPUT_GET, 'post_id', FILTER_VALIDATE_INT) : 0;
            if ($post_id > 0) {
                $reactions = get_reactions($pdo, $post_id);
            } else {
                $reactions = ['likes' => 0, 'dislikes' => 0];
            }
            ?>
            
            <div class="reactions" style="display: flex; justify-content: space-around;">
                <button class="reaction-btn" data-reaction="like" data-post-id="<?= $post_id ?>" 
                        style="font-family: Verdana, Geneva, Tahoma, sans-serif; text-transform: uppercase; font-size: 20px; color: white; background-color: #222a33; border-radius: 20px; padding: 10px 15px; border: 1px solid #686f77; cursor: pointer;" 
                        onmouseover="this.style.backgroundColor='#36567bc5'; this.style.color='white';" 
                        onmouseout="this.style.backgroundColor='#232323'; this.style.color='white';">
                    <span id="like-count"><?= $reactions['likes'] ?? 0 ?></span> 🤍 Likes
                </button>
                <button class="reaction-btn" data-reaction="dislike" data-post-id="<?= $post_id ?>" 
                        style="font-family: Verdana, Geneva, Tahoma, sans-serif; text-transform: uppercase; font-size: 20px; color: white; background-color: #222a33; border-radius: 20px; padding: 10px 15px; border: 1px solid #686f77; cursor: pointer;" 
                        onmouseover="this.style.backgroundColor='#36567bc5'; this.style.color='white';" 
                        onmouseout="this.style.backgroundColor='#232323'; this.style.color='white';">
                    <span id="dislike-count"><?= $reactions['dislikes'] ?? 0 ?></span> 😡 Dislikes
                </button>
            </div>
        </div>

    </section>

    <div class="comments" id="comments comments-section">
        <?= show_comments($pdo, $post_id) ?>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Select the "Write Comment" button
            const writeCommentBtn = document.querySelector('.write_comment_btn');
            console.log('Write comment button:', writeCommentBtn); // Debugging to check if the button is found

            if (writeCommentBtn) {
                // Add the click event listener to toggle the form visibility
                writeCommentBtn.addEventListener('click', function (event) {
                    event.preventDefault(); // Prevent default anchor click behavior
                    console.log('Write comment button clicked'); // Debugging to check if click event is working

                    // Toggle visibility of the write comment form
                    const writeCommentForm = document.getElementById('write_comment_form');
                    if (writeCommentForm) {
                        console.log('Toggling form visibility');
                        writeCommentForm.style.display = writeCommentForm.style.display === 'none' || writeCommentForm.style.display === '' ? 'block' : 'none';
                    }
                });
            }
        });
    </script>

    <script>
        // Dynamically get the post_id from the URL or server
        const postId = <?php echo isset($_GET['ID']) ? intval($_GET['ID']) : 0; ?>;

        // Function to fetch and display comments for the specific post_id
        function loadComments() {
            fetch("comments.php?post_id=" + postId)
                .then(response => response.text())
                .then(data => {
                    // Insert the fetched comments into the comments section
                    document.querySelector(".comments").innerHTML = data;

                    // Attach the event listener to all reply buttons
                    document.querySelectorAll(".comments .reply_comment_btn").forEach(element => {
                        element.onclick = event => {
                            event.preventDefault();

                            // Get the ID of the comment being replied to
                            const commentId = element.getAttribute("data-comment-id");

                            // Hide all existing write comment forms
                            document.querySelectorAll(".comments .write_comment").forEach(form => {
                                form.style.display = 'none';
                            });

                            // Show the reply form for the clicked comment ID
                            const target = document.querySelector("div[data-comment-id='" + commentId + "'] .write_comment");
                            if (target) {
                                target.style.display = 'block';
                                target.querySelector("textarea[name='content']").focus();
                                // Set the hidden field in the form to the correct parent_comment_id
                                target.querySelector("input[name='parent_comment_id']").value = commentId;
                            }
                        };
                    });

                    // Attach event listeners to handle reply submission via AJAX
                    document.querySelectorAll(".comments .reply_form").forEach(form => {
                        form.onsubmit = event => {
                            event.preventDefault();

                            const formData = new FormData(form);

                            // Send the form data via AJAX to 'comments.php'
                            fetch("comments.php?post_id=" + postId, {
                                method: 'POST',
                                body: formData
                            })
                            .then(response => response.text())
                            .then(data => {
                                // After submitting, find the comment with the correct parent_comment_id
                                const parentCommentId = form.querySelector("input[name='parent_comment_id']").value;
                                const parentComment = document.querySelector("div[data-comment-id='" + parentCommentId + "'] .replies");

                                // Append the new reply to the correct comment's replies section
                                if (parentComment) {
                                    parentComment.innerHTML = data; // Replace replies with the updated replies
                                }

                                // Optionally, reset the form or show a success message
                                form.reset(); // Reset the form after submission
                                form.closest('.write_comment').style.display = 'none'; // Hide the form

                                // Reload the comments to reflect any changes
                                loadComments();
                            });     
                        };
                    });
                });
        }

        // Initial load of comments 
        loadComments();
    </script>

    <script>
document.addEventListener('DOMContentLoaded', function () {
    const urlParams = new URLSearchParams(window.location.search);
    const postId = urlParams.get('ID'); // Changed from 'post_id' to 'ID'

    if (postId) {
        function fetchReactionCounts(postId) {
            fetch(`http://localhost/blog/fetch_reaction.php?post_id=${postId}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.status === 'success') {
                        document.getElementById('like-count').textContent = data.likes;
                        document.getElementById('dislike-count').textContent = data.dislikes;
                    } else {
                        console.error('Error fetching reactions:', data.message);
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        document.querySelectorAll('.reaction-btn').forEach(button => {
            button.addEventListener('click', function () {
                const reactionType = this.getAttribute('data-reaction');
                fetch('http://localhost/blog/reaction.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        post_id: postId,
                        reaction_type: reactionType
                    })
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.status === 'success') {
                        fetchReactionCounts(postId);
                    } else {
                        console.error('Error updating reaction:', data.message);
                    }
                })
                .catch(error => console.error('Error:', error));
            });
        });

        // Initial load of reaction counts
        fetchReactionCounts(postId);
    } else {
        console.error('Post ID not found in URL');
    }
});

    </script>

<?php

    include 'partials/footer.php';

?>