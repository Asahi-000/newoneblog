<?php
// Update the details below with your MySQL details
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = '';
$DATABASE_NAME = 'blog';

// PDO database connection setup
try {
    $pdo = new PDO('mysql:host=localhost;dbname=blog;charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

session_start();

include_once('functions.php'); 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if post_id is present in the URL
    if (isset($_GET['post_id']) && is_numeric($_GET['post_id'])) {
        $post_id = $_GET['post_id']; // The post ID from the URL
    } else {
        exit('Error: post_id is missing or invalid!');
    }

    // Get the reply content and the comment being replied to
    $content = $_POST['content'];
    $parent_comment_id = $_POST['parent_comment_id']; // The ID of the comment being replied to
    $user_id = $_SESSION['user_id']; // Get the logged-in user ID from session

    // Ensure the parent_comment_id is valid
    if (!$parent_comment_id || !is_numeric($parent_comment_id)) {
        exit('Invalid parent comment ID!');
    }

    // Set parent_id to 1 for replies
    $parent_id = 1; // Replies are always associated with parent_id = 1

    // Insert the reply into the database
    try {
        $stmt = $pdo->prepare("INSERT INTO comments (post_id, user_id, content, parent_id, parent_comment_id, submit_date) 
                               VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$post_id, $user_id, $content, $parent_id, $parent_comment_id]);

        // After insertion, fetch the updated list of comments and display them
        echo show_comments($pdo, $post_id);  // Display the updated comments including the new reply
    } catch (PDOException $e) {
        // Handle any errors that occur during the insert process
        echo 'Error: ' . $e->getMessage();
    }

    exit;  // Stop further execution
}

if (isset($_GET['post_id'])) {
    $post_id = $_GET['post_id'];

    // Get total number of comments
    $stmt = $pdo->prepare('SELECT COUNT(*) AS total_comments FROM comments WHERE post_id = ?');
    $stmt->execute([$post_id]);
    $comments_info = $stmt->fetch(PDO::FETCH_ASSOC);

    // Display comment header only if comments_info is set
    if ($comments_info) {
        echo "<div class='comment_header'>
            <span class='total'>{$comments_info['total_comments']} comments</span>
            <a href='#' class='write_comment_btn' data-comment-id='-1'>Write Comment</a>
        </div>";
    }

    // Display all comments
    echo show_comments($pdo, $post_id);
}

// Fetch current user details (assuming user ID is stored in session)
if (!isset($_SESSION['user_id'])) {
    exit('User not logged in!');
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare('SELECT ID, username FROM users WHERE ID = ?');
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    exit('User not found!');
}

function show_write_comment_form($parent_id = -1) {
    global $user;
    $full_name = htmlspecialchars($user['username'], ENT_QUOTES); // Username from logged-in user

    $html = '
    <div class="write_comment" data-comment-id="' . $parent_id . '" style="display:none;">
        <form method="POST" action="comments.php?post_id=' . $_GET['post_id'] . '">
            <input name="parent_id" type="hidden" value="' . $parent_id . '">
            <input name="user_id" type="hidden" value="' . htmlspecialchars($user['ID'], ENT_QUOTES) . '">
            <input name="name" type="text" value="' . $full_name . '" placeholder="Your Name" readonly required>
            <textarea name="content" placeholder="Write your comment here..." required></textarea>
            <button type="submit">Submit Comment</button>
        </form>
    </div>
    ';
    return $html;
}

// Get total number of comments
if ($post_id) {
    $stmt = $pdo->prepare('SELECT COUNT(*) AS total_comments FROM comments WHERE post_id = ?');
    $stmt->execute([$post_id]);
    $comments_info = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    exit('No post ID specified!');
}
?>
